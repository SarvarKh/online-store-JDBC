create function get_orders_by_customer(p_customer_id bigint)
    returns TABLE(cust_first_name character varying, cust_last_name character varying, cust_email character varying, order_id bigint, creation_dt timestamp without time zone, total_due numeric, status character varying, sales_first_name character varying, sales_last_name character varying, sales_email character varying, item_quanitty integer, item_code character varying, item_name character varying, item_size integer, item_variety character varying, item_price numeric)
    language plpgsql
as
$$
BEGIN
  RETURN QUERY SELECT
  c.first_name,
  c.last_name,
  c.email,
  o.order_id,
  o.creation_date,
  o.total_due,
  o.status,
  s.first_name,
  s.last_name,
  s.email,
  ol.quantity,
  p.code,
  p.name,
  p.size,
  p.variety,
  p.price
  FROM orders o
  JOIN customer c on o.customer_id = c.customer_id
  JOIN salesperson s on o.salesperson_id = s.salesperson_id
  JOIN order_item ol on ol.order_id = o.order_id
  JOIN product p on ol.product_id = p.product_id
  where c.customer_id = p_customer_id
  order by o.order_id, p.code;
END; $$;

alter function get_orders_by_customer(bigint) owner to sarvarkhalimov;

